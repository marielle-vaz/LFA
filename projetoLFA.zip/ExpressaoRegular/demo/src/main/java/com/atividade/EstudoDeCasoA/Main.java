package com.atividade.EstudoDeCasoA;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {
    public static void main(String[] args) {
        String urlString = "https://noticias.uol.com.br/blogs-e-colunas/";
        try {
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.82 Safari/537.36");

            int responseCode = conn.getResponseCode();

            if (responseCode != HttpURLConnection.HTTP_OK) {
                System.out.println("Erro ao conectar: " + responseCode);
                return;
            }

            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String inputLine;
            StringBuilder content = new StringBuilder();

            while ((inputLine = in.readLine()) != null) {
                content.append(inputLine);
            }

            in.close();
            conn.disconnect();

            String html = content.toString();

            Pattern patternTitle = Pattern.compile("(?<=<span class=\"thumb-kicker kicker-small kicker-lg-large\">)([\\s\\S]*?)(?=<\\/span>)", Pattern.DOTALL);
            Pattern patternText = Pattern.compile("(?<=<h3 class=\"thumb-title title-xsmall title-lg-small\">)([\\s\\S]*?)(?=<\\/h3>)", Pattern.DOTALL);
            Pattern patternAuthor = Pattern.compile("(?<=<p class=\"author\">)([\\s\\S]*?)(?=<\\/p>)", Pattern.DOTALL);

            Matcher matcherTitle = patternTitle.matcher(html);
            Matcher matcherText = patternText.matcher(html);
            Matcher matcherAuthor = patternAuthor.matcher(html);

            FileWriter csvWriter = new FileWriter("titulo_texto_autor.csv");
            csvWriter.append("Título;Texto;Autor\n");

            while (matcherTitle.find() && matcherText.find() && matcherAuthor.find()) {
                String titulo = matcherTitle.group(1).replaceAll("\\s+", " ").trim();
                String texto = matcherText.group(1).replaceAll("\\s+", " ").trim();
                String autor = matcherAuthor.group(1).replaceAll("\\s+", " ").trim();

                csvWriter.append(titulo).append(";")
                        .append(texto).append(";")
                        .append(autor).append("\n");
            }

            System.out.println("Título, texto e autor extraídos com sucesso!");

            csvWriter.flush();
            csvWriter.close();

            Pattern patternName = Pattern.compile("(?<=<h4 class=\"h-components\">)([\\s\\S]*?)(?=<\\/h4>)", Pattern.DOTALL);
            Pattern patternImg = Pattern.compile("(?<=<div class=\"placeholder\"><img src=\"[\\s\\S])([\\s\\S]*?)(?=\" data-src=)", Pattern.DOTALL);

            Matcher matcherName= patternName.matcher(html);
            Matcher matcherImg = patternImg.matcher(html);

            FileWriter csvWriter2 = new FileWriter("nome_imagem.csv");
            csvWriter2.append("Nome;Imagem\n");

            while (matcherName.find() && matcherImg.find()) {
                String nome = matcherName.group(1).replaceAll("\\s+", " ").trim();
                String img = matcherImg.group(1).replaceAll("\\s+", " ").trim();

                csvWriter2.append(nome).append(";")
                        .append(img).append("\n");
            }

            System.out.println("Nome e imagem extraídos com sucesso!");

            csvWriter2.flush();
            csvWriter2.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}